# creator: Haitham Albrashdi
#Date of creation: 2/13/2022
import socket
import math
import os.path

PORT_NUM = 1604
NUM_REQUESTS_ALLOWED = 5
# connect using
#               AF_INET - the Address Family for Internet (IPv4)
#               SOCK_STREAM - TCP as the transport protocol
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server_socket.bind((socket.gethostname(), PORT_NUM))

# only queue up to 5 (set 1 if allowing only only at a time)
server_socket.listen(NUM_REQUESTS_ALLOWED)

#the def for all the function
def checklogin(loginInfo, fileName):
    try:  #handling if the user input invalid format
        username, password = loginInfo.split(" ", 1)
    except:
        return False

    with open(fileName, 'r') as f: #loop to check if the user in the database
        lines = f.readlines()
        for line in lines:
            if username in line and password in line and len(password) > 5:
                return True
            else:
                continue
        return False


def readCode(client_socket): #function to resieve message from user and process it
    msg = client_socket.recv(1024)

    try: #handling if user enter no (input)
        command, input = msg.decode('utf-8').split(" ", 1)
        return command, input

    except:
        command = msg.decode('utf-8')
        return command, None


def sendMsg(msg, client_socket): #To send msg for the user
    client_socket.send(bytes(msg, "utf-8"))


def solve(msg): #for the SOLVE command
    try: #handling if the user enter invalid format
        expr = msg.split()
        if expr[0] == "-c":# check if there is a radius or not
            if len(expr) == 1:
                msg = "Error: No radius found"
                client_socket.send(bytes(msg, "utf-8"))
                toText = f"Error: No radius found" #formatting the result to write it to a file
                return toText
            else:
                try: #if there is a radius then process this
                    radius = expr[1]
                    r = float(radius)
                    circumference = float(2 * math.pi * r)
                    circumference = abs(circumference)
                    circumference = "{:.2f}".format(circumference) #formatting to two decimals
                    circumference = str(circumference)
                    area = float(math.pi * r * r)
                    area = abs(area)
                    area = "{:.2f}".format(area) #formatting to two decimals
                    area = str(area)
                    msg = "Circle circumference is " + circumference + " and area is " + area
                    client_socket.send(bytes(msg, "utf-8"))
                    toText = f"radius {radius} : Circle circumference is {circumference} and area is {area}"
                    return toText
                except:
                    sendMsg("S: 301 invalid format", client_socket)
                    return

        elif expr[0] == "-r": #for the -r command if no sides found
            if len(expr) == 1:
                msg = "Error: No sides found"
                client_socket.send(bytes(msg, "utf-8"))
                toText = "Error: no sides found"
                return toText

            elif len(expr) == 2:
                try: #if the user enter one side
                    sides = expr[1]
                    s = float(sides)
                    perimeter = float(4 * s)
                    perimeter = abs(perimeter)
                    perimeter = "{:.2f}".format(perimeter) #formatting
                    perimeter = str(perimeter) #convert to string
                    area = float(s * s)
                    area = abs(area)
                    area = "{:.2f}".format(area)
                    area = str(area)
                    msg = "Rectangle's perimeter is " + perimeter + " and area is " + area #printing
                    client_socket.send(bytes(msg, "utf-8"))
                    toText = f"sides {sides} {sides} : Rectangle's perimeter is {perimeter} and area is {area}" #for the file format
                    return toText
                except:
                    sendMsg("S: 301 invalid format")
                    return

            elif len(expr) == 3:
                try: #if the user enter two sides
                    s1 = float(expr[1])
                    s2 = float(expr[2])
                    perimeter = float(2 * (s1 * s2)) #calculating
                    perimeter = abs(perimeter)
                    perimeter = "{:.2f}".format(perimeter)
                    perimeter = str(perimeter)
                    area = float(s1 * s2)
                    area = abs(area)
                    area = "{:.2f}".format(area)
                    area = str(area)
                    msg = "Rectangle's circumference is " + perimeter + " and area is " + area
                    client_socket.send(bytes(msg, "utf-8"))
                    toText = f"sides {s1} {s2} : Rectangle's perimeter is {perimeter} and area is {area}"
                    return msg
                except:
                    sendMsg("S: 301 invalid format", client_socket)
                    return

        else:#to handle the errors if the user enter invalid format
            sendMsg("S: 301 invalid format", client_socket)
            return
    except:
        sendMsg("S: 301 invalid format", client_socket)
        return


def writeToFile(input, info): #write to the file with the user's username
    username = input[0] #initializing to the username
    if os.path.exists(f"{username}_solutions.txt"): #check if the file exists to format it correctly
        file = open(f"{username}_solutions.txt", "a")
        file.write(f"\n{info.strip()}")
    else:
        file = open(f"{username}_solutions.txt", "a") #if the file is not exists then create one and write on it
        file.write(f"{username}:\n{info.strip()}")
    file.close()


def printFile(input, client_socket): #to print a file
    username = input
    try: #handling if the user didnt interact with the server yet
        f = open(f"{username}_solutions.txt", 'r') #read the file and print it to the client screen
        line = f.read()
        sendMsg(line, client_socket)

    except:
        client_socket.send(bytes(f"S: {username}\nNo interaction from the user yet", 'utf-8'))

def list(input, client_socket): #for LIST command
    username = input[0]
    printFile(username, client_socket) #calling function to print the file with username


def checkRoot(input): #check if the user is the root or not
    username = input[0]
    if username == "root":
        return True
    else:
        return False


def printAll(client_socket): #to print all the users files when the root ask
    listAll = ""
    userFile = open("logins.txt", 'r')  #open users information file
    with userFile as file:
        for line in file.readlines():
            line = line.split() #split to get only the username
            username = line[0]
            try: #check if the user interact with the server or not
                f = open(f"{username}_solutions.txt", 'r') #open the file with username
                l = f.read()
                listAll += f"{l}\n" #store information in the variable
                f.close()
            except: #print this when the user doesn't interact with the server
               listAll += f"{username}:\nNo interaction from the user yet\n"
    sendMsg(listAll, client_socket) ##printint


def logout(client_socket): #to logout the client from the server
    sendMsg("S: 200 OK", client_socket)
    client_socket.close()


def shutdown(client_socket): #to shutdown the server
    sendMsg("S: 200 OK", client_socket)
    logout(client_socket)
    exit()


while True:
    client_socket, address = server_socket.accept()
    while True:
        try:
            command, input = readCode(client_socket)#get the message from the user
            command = command.strip()
            userInfo = input.split() #store user info
        except:
            pass
        if command == "LOGIN":
            # checking the username and password
            flag = checklogin(input, "logins.txt")
            temp = ""

            if flag: #if the username and password are correct then connect and log in
                print(f"connection established with {address}")
                sendMsg("S: You logged in successfully", client_socket)
                command, input = readCode(client_socket) #take msg from the server

                while True: #looping to exceute all the user command until the user logout or shutdown
                    if command == "LOGIN":
                        sendMsg("S: You are already logged in", client_socket)

                    elif command == "SOLVE":
                        if input: #to handle if the user didnt enter any (input) with SOLVE
                            try:
                                info = solve(input)
                                writeToFile(userInfo, info)
                            except:
                                pass
                        else:
                            sendMsg("S: 301 message format error", client_socket)

                    elif command == "LIST":
                        if input: #to handle LIST
                            if input == "-all": #if the user ask for all we check root
                                isRoot = checkRoot(userInfo)
                                if isRoot: #if the user is root then print all users information
                                    printAll(client_socket)
                                else:
                                    sendMsg("S: You are not the root", client_socket)
                            else:
                                sendMsg("S: 300 command invalid", 'utf-8')
                        else:# if the user asks for LIST only
                            list(userInfo, client_socket)

                    elif command == "LOGOUT":#to logout
                        logout(client_socket)
                        break

                    elif command == "SHUTDOWN": #to shutdown
                        shutdown(client_socket)
                    else:
                        sendMsg("S: 300 invalid command", client_socket)# if the user enter invalid command

                    try:
                         command, input = readCode(client_socket)

                    except:
                        command = readCode(client_socket)
                        command = command.strip()
            else: #if the user didnt enter the correct username and password
                client_socket.send(bytes("S: Please Enter the correct password and username", "utf-8"))
        else:
            try:
                client_socket.send(bytes("S: 300 invalid command", 'utf-8'))
            except:
                break