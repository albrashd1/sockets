# creator: Haitham Albrashdi
#Date of creation: 2/13/2022

import socket

PORT_NUM = 1604
NUM_BYTES = 1024

#Making socket then connect
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((socket.gethostname(), PORT_NUM))

while True:
    #taking input from client and send it to the server
    msg = input("C: ")
    client_socket.send(bytes(msg, 'utf-8'))
    data = client_socket.recv(1024) #recieve response from the server
    data = data.decode('utf-8')
    print(data)

    if data == "S: 200 OK": #To close the connection from the user
        client_socket.close()
        exit()


